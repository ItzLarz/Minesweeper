# MineSweeper
MineSweeper made in JavaScript with p5.js
